/*
 *
 *
 * Loesung  W.Pauly 
 *
 *
 */




//
//
//
// dekl. des funktionalen Interfaces
public interface MyFunction
  {
    public int apply ( int i );
  }
 
