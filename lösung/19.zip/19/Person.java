// Java-Beispiele
// Prof. Dr. H. G. Folz
// 2001

 
import de.htw.saarland.stl.Stdin;


public class Person implements java.io.Serializable
{
  public Person() {}

  public Person( String name, String vorname) {
      this.name    = name;
      this.vorname = vorname;
  }

  public void eingeben() {
      name    = Stdin.readlnString( "Name:    " );
      vorname = Stdin.readlnString( "Vorname: " );
  }

  public void ausgeben() {
      System.out.print( name + ", " + vorname );
  }

  public void setName(String n) {
      name = n;
  }

  public void setVorname(String vn) {
      vorname = vn;
  }

  public String getName() {
      return name;
  }

  public String getVorname() {
      return vorname;
  }
  
  public String toString() {
      return name + ", " + vorname;
  }

  protected String name;
  protected String vorname;
}
