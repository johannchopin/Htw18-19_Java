
import java.util.Random;

public class Producer 
  {
     private Random ran;


    public Producer()
      {
       this.ran = new Random();
      }


    public int produce()
      {
       int product = ran.nextInt(1001);

       System.out.println("I produced "+product);
       return product;
      }
  }
